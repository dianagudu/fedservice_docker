class Revoked(Exception):
    pass


class MintingNotAllowed(Exception):
    pass
